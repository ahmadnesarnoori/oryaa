<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Deposit extends Model
{



}
